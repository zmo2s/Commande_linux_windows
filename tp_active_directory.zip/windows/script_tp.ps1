﻿#creation du tableau associatif 
#seperation sur le charactere ;
$ADUsers=Import-csv C:\scripts\etudiants.csv -Delimiter ";"


# declaration de la cste
$pass="Mercredi/34!";
# conversion du mdp sur secureString pour supprimer le texte de la mememoire de l'ordi
$securepwd=ConvertTo-SecureString $pass -AsPlainText -Force;

$array = Get-ADUser -Filter * -SearchBase "OU=EtudiantsEPSI,DC=epsi,DC=local";

   
foreach ($User in $ADUsers)
{
       #region GetAttributs       
       $prenom = $User.'Pr�nom';
       $nom = $User.Nom;
       $EmployeID = $User.'Num�ro d''identification';
       $email = $User.'Adresse de courriel';
       $groupe=$User.Groupe;
       $username= $prenom[0]+$nom;
       #endregion


       

       

       # echo $array.SamAccountName;
       # echo $username;
               If ( $array.SamAccountName.contains($username))
        {
         echo "utilsiateur deja inscrit $nom";
        }

  
        Else {
      
       # ajout d'un utilisateur -name nom prenom plus bas pour evite les personnes ayant le meme nom dee famille
       New-aduser –name "$nom $prenom" –surname $prenom –AccountPassword $securepwd  –SamAccountName $username –userprincipalname “$username@epsi.local" -EmployeeID $EmployeID  -enabled $true -Path "OU=EtudiantsEPSI,DC=epsi,DC=local" -ChangePasswordAtLogon $true -DisplayName "$nom $prenom" -EmailAddress $email;
        
       # ajouter un utilisateur dnas un groupe
       Add-ADGroupMember -Identity "Bachelor2INIMTP" -Members $username;           
      
          # critere de selection pour ajouter dans un groupe   
          If ($groupe -eq 'C1')
          {
          Add-ADGroupMember -Identity "Bachelor2INMTPC1" -Members $username;
          }

          If($groupe -eq 'C2')
          {
          Add-ADGroupMember -Identity "Bachelor2INIMTPC2" -Members $username;
          }
          }
          

}




#New-aduser –name "nom13" –surname "prenom12" –AccountPassword $securepwd  –SamAccountName "login13“ –userprincipalname “login13@epsi.local" -enabled $true -Path "OU=EtudiantsEPSI,DC=epsi,DC=local" -ChangePasswordAtLogon $true
#Add-ADGroupMember -Identity "Bachelor2INIMTP" -Members "login13" 
#DSADD ou ou="lol,DC=epsi,DC=local";


#$nbr=0;
#$b=@();

#foreach ($User in $ADUsers)
#{
#  if($b.Contains($User.Nom))
 # {
  #  $nbr=$nbr+1;
  #}
  #$b+=$User.Nom;
#$nbr=0;
